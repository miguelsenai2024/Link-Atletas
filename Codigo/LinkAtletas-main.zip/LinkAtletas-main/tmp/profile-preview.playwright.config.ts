import { defineConfig } from '@playwright/test'
export default defineConfig({
  testDir: '../tests/e2e',
  testMatch: 'profile-preview.spec.ts',
  workers: 1,
  reporter: 'list',
  outputDir: './profile-preview-test-results',
  use: {
    baseURL: 'http://127.0.0.1:5196',
    viewport: { width: 1440, height: 1000 },
    reducedMotion: 'reduce',
    launchOptions: { executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe' },
  },
})
