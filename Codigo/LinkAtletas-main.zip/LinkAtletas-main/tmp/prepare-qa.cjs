const fs=require('fs');
let script=fs.readFileSync('teste/qa/verify.cjs','utf8');
script=script.replaceAll('5190','5191').replaceAll("'.menu-toggle'","'.lp-menu-toggle'").replaceAll("'.faq details'","'.lp-faq details'").replaceAll("font.family === 'Manrope'","font.family === 'LandingManrope'").replaceAll('teste/qa/hero-','tmp/official-hero-').replace('teste/qa/results.json','tmp/official-results.json');
script=script.replace("await page.goto('http://127.0.0.1:5191/')", "await page.route('**/api/auth/session', route => route.fulfill({json:{user:null}})); await page.goto('http://127.0.0.1:5191/')");
fs.writeFileSync('tmp/verify-official.cjs',script);
