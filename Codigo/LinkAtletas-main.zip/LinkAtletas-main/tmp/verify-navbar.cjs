const { chromium, expect } = require('@playwright/test');
const assert = require('node:assert/strict');
(async () => {
 const browser = await chromium.launch({ executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe', headless: true });
 try {
  for (const width of [1440, 390]) for (const role of ['athlete', 'coach', 'admin']) {
   const context = await browser.newContext({ viewport: { width, height: 1000 } });
   const page = await context.newPage();
   const errors = [];
   page.on('pageerror', e => errors.push(e.message));
   const root = role === 'athlete' ? '/atleta' : role === 'coach' ? '/treinador' : '/admin';
   await page.route('**/api/**', async route => {
    const path = new URL(route.request().url()).pathname;
    let json = { contracts: [], workouts: [], coaches: [], reviews: [], reports: [], notifications: [], unread: 0, verifications: [], metrics: [], average: 0, count: 0 };
    if (path.endsWith('/auth/session')) json = { user: { id: 'user-1', name: 'Marina', role, email: 'test@example.com' } };
    await route.fulfill({ json });
   });
   await page.goto('http://127.0.0.1:5181' + root);
   if (width < 900) await page.getByRole('button', { name: 'Abrir menu', exact: true }).click();
   const nav = page.getByRole('navigation', { name: 'Navegação principal' });
   await expect(nav.getByRole('button', { name: 'Principal', exact: true })).toHaveAttribute('aria-expanded', 'false');
   assert.equal(await page.locator('.neo-dots').count(), 0);
   const ids = role === 'admin' ? ['principal', 'consultas'] : ['principal', 'social', 'consultas'];
   for (const id of ids) {
    const branch = page.locator('#nav-branch-' + id);
    const button = nav.locator('[aria-controls="nav-branch-' + id + '"]');
    await button.click();
    await expect(button).toHaveAttribute('aria-expanded', 'true');
    await expect(branch).toBeVisible();
    await expect.poll(() => branch.evaluate(el => el.getBoundingClientRect().height)).toBeGreaterThan(60);
    if (role === 'athlete' && id === 'principal') {
     await branch.screenshot({ path: 'tmp/navbar-open-' + width + '.png', animations: 'disabled' });
     await branch.getByRole('link', { name: 'Início', exact: true }).click();
     await expect(button).toHaveAttribute('aria-expanded', 'false');
     await expect(branch).toHaveAttribute('inert', '');
     if (width < 900) await page.getByRole('button', { name: 'Abrir menu', exact: true }).click();
     await button.click();
    }
    const link = branch.locator('a').nth(1);
    const target = await link.getAttribute('href');
    await link.click();
    await expect(page).toHaveURL('http://127.0.0.1:5181' + target);
    await expect(page.locator('.neo-group.is-open')).toHaveCount(0);
    await expect.poll(() => page.locator('#nav-branch-' + id).evaluate(el => getComputedStyle(el).visibility)).toBe('hidden');
    if (width < 900) {
     await expect(page.locator('.sidebar--open')).toHaveCount(0);
     await page.getByRole('button', { name: 'Abrir menu', exact: true }).click();
    }
   }
   await page.emulateMedia({ reducedMotion: 'reduce' });
   await nav.getByRole('button', { name: 'Principal', exact: true }).click();
   const duration = await page.locator('#nav-branch-principal').evaluate(el => getComputedStyle(el).transitionDuration);
   assert.ok(duration.split(',').every(value => parseFloat(value) <= 0.001));
   await page.keyboard.press('Escape');
   await expect(page.locator('.neo-group.is-open')).toHaveCount(0);
   assert.deepEqual(errors, []);
   console.log(JSON.stringify({ width, role, navigation: 'passed', sameRoute: role === 'athlete' ? 'passed' : 'not applicable', reducedMotion: 'passed', pageErrors: errors }));
   await context.close();
  }
 } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exit(1); });
