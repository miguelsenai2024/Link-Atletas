const { chromium, expect } = require('@playwright/test');
const assert = require('node:assert/strict');
(async () => {
 const browser = await chromium.launch({ executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe', headless: true });
 try {
 for (const width of [390]) for (const role of ['coach']) {
  const page = await browser.newPage({ viewport: { width, height: 1000 } });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.route('**/api/**', route => route.fulfill({ json: route.request().url().includes('/auth/session') ? { user: { id: '1', name: 'Marina', role } } : { contracts: [], workouts: [], notifications: [], unread: 0 } }));
  await page.goto('http://127.0.0.1:5182/' + (role === 'coach' ? 'treinador' : 'atleta'));
  await expect(page.locator('.neo-visual-card')).toBeVisible(); await expect(page.locator('.live-panel').first()).toBeVisible();
  const styles = await page.evaluate(() => {
   const style = selector => getComputedStyle(document.querySelector(selector));
   return {
    background: style('.neo-shell').backgroundColor,
    backgroundImage: style('.neo-shell').backgroundImage,
    navbar: style('.neo-rail').backgroundColor,
    header: style('.neo-header').backgroundColor,
    borders: ['.neo-visual-card', '.live-hero', '.live-panel'].map(selector => style(selector).borderTopWidth),
    shadows: ['.neo-visual-card', '.live-hero', '.live-panel'].map(selector => style(selector).boxShadow),
    horizontalOverflow: document.documentElement.scrollWidth > innerWidth,
   };
  });
  assert.equal(styles.background, 'rgb(35, 35, 35)');
  assert.equal(styles.backgroundImage, 'none');
  assert.equal(styles.navbar, 'rgb(24, 24, 24)');
  assert.equal(styles.header, 'rgb(24, 24, 24)');
  assert.ok(styles.borders.every(border => border === '0px'));
  assert.ok(styles.shadows.every(shadow => shadow !== 'none'));
  assert.equal(styles.horizontalOverflow, false);
  assert.deepEqual(errors, []);
  if (role === 'coach') await page.screenshot({ path: 'tmp/dashboard-colors-' + width + '.png', fullPage: true });
  console.log(JSON.stringify({ width, role, ...styles, errors }));
  await page.close();
 }
 } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exit(1); });

