const fs = require('fs');
const postcss = require('../node_modules/.pnpm/postcss@8.5.26/node_modules/postcss');
let html = fs.readFileSync('teste/index.html', 'utf8').split('<body>')[1].split('</body>')[0].trim();
html = html.replace(/class="([^"]*)"/g, (_, c) => `className="${c.split(/\s+/).map(x=>'lp-'+x).join(' ')}"`)
 .replaceAll('src="assets/', 'src="/landing/').replaceAll(' for=', ' htmlFor=')
 .replaceAll('fetchpriority=', 'fetchPriority=').replaceAll('stroke-width=', 'strokeWidth=')
 .replace(/<(img|br)(\s[^>]*|)>/g, '<$1$2 />');
html = html.replace(/<a([^>]*?)href="\.\.\/login([^\"]*)"([^>]*)>([\s\S]*?)<\/a>/g, (_, a, query, b, content) => `<Link${a}to="/login${query.includes('treinador')?'?cadastro=1&perfil=treinador':query}"${b}>${content}</Link>`);
html = html.replace('id="navigation"', 'id="navigation" className={menuOpen ? \'lp-is-open\' : \'\'} onClick={() => setMenuOpen(false)}');
html = html.replace('aria-expanded="false" aria-controls="navigation" aria-label="Abrir menu"', 'ref={menuButton} onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen} aria-controls="navigation" aria-label={menuOpen ? \'Fechar menu\' : \'Abrir menu\'}');
html = html.replace('id="match-form"', 'id="match-form" onSubmit={submitMatch}');
for (const field of ['sport','goal','format']) html = html.replace(`id="${field}" name="${field}" required`, `id="${field}" name="${field}" required value={answers.${field}} onChange={event => { setAnswers({ ...answers, ${field}: event.target.value }); setResult(null) }}`);
html = html.replace('<div className="lp-match-result" id="match-result" role="status" hidden></div>', `<div className="lp-match-result" id="match-result" role="status" ref={resultElement} hidden={!result}>{result && <>
          <h3>Seu próximo passo já tem direção.</h3>
          <p>{result.sport} · Acompanhamento {result.format.toLowerCase()}. {goalCopy[result.goal]}</p>
          <Link className="lp-text-link" to="/login?cadastro=1&perfil=atleta">Criar meu perfil na LinkAtletas ↗</Link>
          <small>Prévia de jornada. A busca de profissionais acontece na plataforma, após o cadastro.</small>
        </>}</div>`);
const preamble = `import { useEffect, useRef, useState, type FormEvent, type MouseEvent } from 'react'
import { Link } from 'react-router-dom'
import './landing.css'

const goalCopy: Record<string, string> = {
  'começar': 'Começar com orientação e um plano que respeite seu ponto de partida.',
  'constância': 'Construir uma rotina possível, com acompanhamento ao longo do caminho.',
  performance: 'Ajustar seus treinos aos seus objetivos e acompanhar a evolução com seu treinador.',
}

export function LandingPage() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [answers, setAnswers] = useState({ sport: '', goal: '', format: '' })
  const [result, setResult] = useState<typeof answers | null>(null)
  const menuButton = useRef<HTMLButtonElement>(null)
  const resultElement = useRef<HTMLDivElement>(null)

  useEffect(() => {
    window.scrollTo(0, 0)
    const root = document.documentElement
    const previousPadding = root.style.scrollPaddingTop
    root.style.scrollPaddingTop = '30px'
    return () => { root.style.scrollPaddingTop = previousPadding }
  }, [])

  useEffect(() => {
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && menuOpen) {
        setMenuOpen(false)
        menuButton.current?.focus()
      }
    }
    const desktop = window.matchMedia('(min-width: 761px)')
    const closeOnResize = () => setMenuOpen(false)
    document.addEventListener('keydown', closeOnEscape)
    desktop.addEventListener('change', closeOnResize)
    return () => {
      document.removeEventListener('keydown', closeOnEscape)
      desktop.removeEventListener('change', closeOnResize)
    }
  }, [menuOpen])

  useEffect(() => {
    if (result) resultElement.current?.scrollIntoView({ block: 'nearest', behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' })
  }, [result])

  function selectSport(event: MouseEvent<HTMLDivElement>) {
    const target = event.target instanceof Element ? event.target.closest<HTMLAnchorElement>('a[data-sport]') : null
    if (target?.dataset.sport) {
      setAnswers(current => ({ ...current, sport: target.dataset.sport! }))
      setResult(null)
    }
  }

  function submitMatch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (answers.sport && answers.goal && answers.format) setResult({ ...answers })
  }

  return <div className="editorial-landing" onClick={selectSport}>
`;
fs.writeFileSync('src/pages/LandingPage.tsx', preamble + html + '\n  </div>\n}\n');
const css = postcss.parse(fs.readFileSync('teste/styles.css', 'utf8'));
css.walkAtRules('keyframes', rule=>rule.params='lp-'+rule.params);
css.walkRules(rule=>{
 if (rule.parent.type==='atrule' && rule.parent.name==='keyframes') return;
 if (rule.selector==='html') { rule.remove(); return; }
 rule.selectors = rule.selectors.map(selector=>{
   if (selector===':root' || selector==='body') return '.editorial-landing';
   const prefixed = selector.replace(/(\[[^\]]*\])|\.([a-zA-Z_][\w-]*)/g, (m, attribute, name)=>attribute || '.lp-'+name);
   return '.editorial-landing '+prefixed;
 });
});
css.walkDecls(decl=>{
 decl.value = decl.value.replaceAll('assets/manrope.ttf','/landing/manrope.ttf').replace(/\bManrope\b/g,'LandingManrope').replace(/\barrive\b/g,'lp-arrive');
});
css.append('.editorial-landing { font-size: 16px; line-height: normal; min-height: 100vh; }\n.editorial-landing h1, .editorial-landing h2, .editorial-landing h3 { font-family: inherit; }');
fs.writeFileSync('src/pages/landing.css', css.toString());
let index = fs.readFileSync('index.html','utf8');
index = index.replace('content="#101916"','content="#181818"').replace('LinkAtletas — conexão inteligente entre atletas e treinadores.', 'Seu ritmo, sua meta, o treinador certo. Conecte-se a profissionais do esporte com a LinkAtletas.').replace('<title>LinkAtletas</title>','<title>LinkAtletas — Movimento em comum.</title>');
fs.writeFileSync('index.html',index);

