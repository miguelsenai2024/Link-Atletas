const { chromium, expect } = require('@playwright/test');
(async () => {
 const browser = await chromium.launch({ executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe', headless: true });
 try {
 for (const width of [1440, 390]) {
  const page = await browser.newPage({ viewport: { width, height: 1000 } });
  await page.route('**/api/**', r => r.fulfill({ json: r.request().url().includes('/auth/session') ? { user: { id: '1', name: 'Marina', role: 'athlete' } } : { contracts: [], workouts: [], notifications: [], unread: 0 } }));
  await page.goto('http://127.0.0.1:5181/atleta');
  if (width === 390) await page.getByRole('button', { name: 'Abrir menu', exact: true }).click();
  await page.getByRole('button', { name: 'Principal', exact: true }).click();
  await expect.poll(() => page.locator('#nav-branch-principal').evaluate(e => e.getAnimations().length)).toBe(0);
  await page.screenshot({ path: 'tmp/navbar-final-' + width + '.png' });
  console.log(JSON.stringify({ width, box: await page.locator('#nav-branch-principal').boundingBox() }));
  await page.close();
 }
 } finally { await browser.close(); }
})().catch(e=>{console.error(e);process.exit(1)});
