import { defineConfig } from '@playwright/test'
export default defineConfig({
 testDir: '../tests/e2e',
 testMatch: 'athlete-controls.spec.ts',
 workers: 1,
 retries: 0,
 timeout: 20000,
 reporter: 'list',
 outputDir: './athlete-controls-results',
 use: { baseURL: 'http://127.0.0.1:5180', channel: 'chrome' },
 projects: [
  { name: 'desktop', use: { viewport: { width: 1440, height: 1000 } } },
  { name: 'mobile', use: { viewport: { width: 390, height: 844 } } },
 ],
})
