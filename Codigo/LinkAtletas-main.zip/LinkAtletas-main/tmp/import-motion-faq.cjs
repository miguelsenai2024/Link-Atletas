const fs = require('node:fs');
let source = fs.readFileSync('reactbits/motionfaqs/tsx.txt', 'utf8').replace(/\r\n/g, '\n');
source = source.replace('import { motion } from "motion/react";', 'import { motion, useReducedMotion } from "motion/react";');
source = source.replace('import { cn } from "@/lib/utils";', 'import "./MotionAccordion.css";');
source = source.replace('  const contentRef =', '  const reducedMotion = useReducedMotion();\n  const contentRef =');
source = source.replace(`className={cn(
        "overflow-hidden rounded-[30px] bg-surface text-foreground shadow-xs",
        isOpen && " ",
      )}`, 'className="motion-accordion__item"');
source = source.replace('      layout\n', '      layout={!reducedMotion}\n');
source = source.replace('transition={{ type: "spring", stiffness: 280, damping: 28, mass: 0.9 }}', 'transition={reducedMotion ? { duration: 0 } : { type: "spring", stiffness: 280, damping: 28, mass: 0.9 }}');
source = source.replace('animate={{ scale: isOpen ? 1 : 0.985 }}', 'animate={{ scale: reducedMotion || isOpen ? 1 : 0.985 }}');
source = source.replace('className="flex w-full cursor-pointer select-none items-center justify-between gap-4 px-7 py-5 text-left"', 'className="motion-accordion__trigger"');
source = source.replace('className="text-[clamp(1.2rem,1.6vw,1.3rem)] font-medium tracking-tight leading-snug"', 'className="motion-accordion__question"');
source = source.replace('transition={{ type: "spring", stiffness: 480, damping: 28 }}', 'transition={reducedMotion ? { duration: 0 } : { type: "spring", stiffness: 480, damping: 28 }}');
source = source.replace('className="inline-flex size-12 shrink-0 items-center justify-center text-foreground"', 'className="motion-accordion__icon"');
source = source.replace('        role="region"', '        role="region"\n        aria-hidden={!isOpen}\n        inert={!isOpen}');
source = source.replace('transition={{\n          height:', 'transition={reducedMotion ? { duration: 0 } : {\n          height:');
source = source.replace('animate={{ y: isOpen ? 0 : -8 }}', 'animate={{ y: reducedMotion || isOpen ? 0 : -8 }}');
source = source.replace('transition={{\n            type: "spring",', 'transition={reducedMotion ? { duration: 0 } : {\n            type: "spring",');
source = source.replace('className="px-7 pb-7"', 'className="motion-accordion__content"');
source = source.replace('className="text-lg leading-8 font-base tracking-normal text-foreground/75"', 'className="motion-accordion__answer"');
source = source.replace('className={cn("w-full", className)}', 'className={["motion-accordion", className].filter(Boolean).join(" ")}');
source = source.replace('className="flex flex-col rounded-[34px] p-3 "', 'className="motion-accordion__list"');
fs.writeFileSync('src/components/MotionAccordion.tsx', source);
let landing = fs.readFileSync('src/pages/LandingPage.tsx','utf8');
landing = landing.replace("import './landing.css'", "import './landing.css'\nimport { MotionAccordion } from '../components/MotionAccordion'");
const start = landing.indexOf('      <div className="lp-faq-list">');
const end = landing.indexOf('      </div>',start) + '      </div>'.length;
const old = landing.slice(start,end);
const items = [...old.matchAll(/<details[^>]*><summary>(.*?)<span[^>]*><\/span><\/summary><p>(.*?)<\/p><\/details>/g)].map(([,question,answer])=>({question,answer}));
if(items.length!==6) throw Error('Expected all six existing FAQs');
landing=landing.slice(0,start)+'      <MotionAccordion className="lp-faq-list" items={landingFaqs} />'+landing.slice(end);
landing=landing.replace('export function LandingPage()', 'const landingFaqs = '+JSON.stringify(items,null,2)+'\n\nexport function LandingPage()');
fs.writeFileSync('src/pages/LandingPage.tsx',landing);
