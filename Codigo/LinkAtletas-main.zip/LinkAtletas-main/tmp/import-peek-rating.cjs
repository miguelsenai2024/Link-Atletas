const fs = require('node:fs');
let source = fs.readFileSync('reactbits/starcode/code.txt', 'utf8');
source = source.replace("import { useEffect, useLayoutEffect, useRef, useState } from 'react';", "import { useEffect, useLayoutEffect, useRef, useState, type CSSProperties, type KeyboardEvent, type PointerEvent, type ReactNode } from 'react';");
source = source.replace("const clamp = (value, min, max)", "const clamp = (value: number, min: number, max: number)");
source = source.replace('export default function PeekRating({', `interface PeekRatingProps {
  value?: number;
  defaultValue?: number;
  onChange?: (value: number) => void;
  onPreview?: (value: number | null) => void;
  count?: number;
  shape?: keyof typeof SHAPES;
  icon?: ReactNode;
  labels?: string[];
  activeColor?: string;
  idleColor?: string;
  tipColor?: string;
  tipTextColor?: string;
  size?: number;
  lift?: number;
  magnify?: number;
  riseDuration?: number;
  popScale?: number;
  showTip?: boolean;
  allowClear?: boolean;
  readOnly?: boolean;
  disabled?: boolean;
  ariaLabel?: string;
  className?: string;
}

export default function PeekRating({`);
source = source.replace("  ariaLabel = 'Rating',", "  ariaLabel = 'Nota',");
source = source.replace("}) {\n  const [inner", "}: PeekRatingProps) {\n  const [inner");
source = source.replace('useRef(null)', 'useRef<HTMLDivElement>(null)');
source = source.replace('const tipEl = useRef<HTMLDivElement>(null)', 'const tipEl = useRef<HTMLSpanElement>(null)');
source = source.replace('const starEls = useRef([])', 'const starEls = useRef<(HTMLButtonElement | HTMLSpanElement | null)[]>([])');
source = source.replace('const liftEls = useRef([])', 'const liftEls = useRef<(HTMLSpanElement | null)[]>([])');
source = source.replace('const glyphEls = useRef([])', 'const glyphEls = useRef<(HTMLSpanElement | null)[]>([])');
source = source.replace('const st = useRef({', `const st = useRef<{
    hover: number | null;
    pressing: boolean;
    pointerId: number | null;
    settled: boolean;
    rect: DOMRect | null;
    rtl: boolean;
  }>({`);
source = source.replace('glyphEl.dataset.lit = i < shown;', 'glyphEl.dataset.lit = String(i < shown);');
source = source.replace('const setHover = index =>', 'const setHover = (index: number | null) =>');
source = source.replace('const indexAt = (x, y) =>', 'const indexAt = (x: number, y: number) =>');
source = source.replace('const commit = (next, pop = true) =>', 'const commit = (next: number, pop = true) =>');
for (const name of ['handlePointerEnter', 'handlePointerDown', 'handlePointerMove', 'endPress']) {
  source = source.replace(`const ${name} = e =>`, `const ${name} = (e: PointerEvent<HTMLDivElement>) =>`);
}
source = source.replace('const handleKeyDown = e =>', 'const handleKeyDown = (e: KeyboardEvent<HTMLDivElement>) =>');
source = source.replace('let next;', 'let next: number;');
source = source.replace('starEls.current.indexOf(e.target)', 'starEls.current.indexOf(e.target as HTMLButtonElement | HTMLSpanElement)');
source = source.replace('`${value} of ${count}`', '`${value} de ${count} estrelas`');
source = source.replace('`${i + 1} of ${count}, ${labels[i]}`', '`${i + 1} de ${count}, ${labels[i]}`').replace('`${i + 1} of ${count}`', '`${i + 1} de ${count} estrelas`');
source = source.replace("'--pr-rise': `${riseDuration}ms`\n      }}", "'--pr-rise': `${riseDuration}ms`\n      } as CSSProperties}");
fs.writeFileSync('src/components/PeekRating.tsx', source);
fs.copyFileSync('reactbits/starcode/CSS.txt', 'src/components/PeekRating.css');
