<img alt="Spell UI - Beautiful UI components for modern React" src="https://spell.sh/og?title=Spell%20UI&description=Beautiful%2C%20sophisticated%20UI%20components" width="100%">

<h3 align="center">Spell UI</h3>

<p align="center">
  Beautiful, sophisticated UI components designed for modern React and Tailwind CSS applications.
</p>

<div align="center">
  <a href="https://github.com/xxtomm/spell-ui/stargazers"><img alt="GitHub Repo stars" src="https://img.shields.io/github/stars/xxtomm/spell-ui"></a>
  <a href="https://x.com/sushidrip"><img alt="Twitter Follow" src="https://img.shields.io/twitter/follow/sushidrip"></a>
  <a href="https://github.com/xxtomm/spell-ui/blob/main/LICENSE"><img alt="License" src="https://img.shields.io/badge/License-MIT-yellow.svg"></a>
  <a href="https://discord.gg/CxzqwQ2EAa"><img alt="Discord" src="https://img.shields.io/badge/Discord-join-blue.svg"></a>
</div>

## Documentation

Visit https://spell.sh/docs to view the documentation.

## Contributing

Visit our [contributing guide](https://github.com/xxtomm/spell-ui/blob/main/CONTRIBUTING.md) to learn how to contribute.

## Community

Have questions, comments or feedback? [Join our Discord](https://discord.gg/CxzqwQ2EAa).

## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=xxtomm/spell-ui&type=Date)](https://www.star-history.com/#xxtomm/spell-ui&Date)


## License

Licensed under the [MIT license](https://github.com/xxtomm/spell-ui/blob/main/LICENSE).
