# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: athlete-controls.spec.ts >> avaliação antecipada permite voltar, escapar e publicar apenas ao confirmar
- Location: tests\e2e\athlete-controls.spec.ts:83:1

# Error details

```
Error: browserType.launch: Executable doesn't exist at C:\Users\SnyX\AppData\Local\ms-playwright\chromium_headless_shell-1248\chrome-headless-shell-win64\chrome-headless-shell.exe
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```