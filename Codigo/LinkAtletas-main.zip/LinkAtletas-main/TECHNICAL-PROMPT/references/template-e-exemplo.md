# Referência: Template Original e Exemplo Preenchido

## 1. Por que essa estrutura funciona no Orchestrator (Argon)

- **Escopo Modular com arquivos separados:** Ao dividir a entrega em blocos que tocam arquivos diferentes (Módulo 1, 2, 3 e Testes), o Argon consegue atribuir cada módulo a subagentes Hydrogen em paralelo sem sobrescrita de arquivos.
- **Definição de entradas e saídas (Contratos):** Especificar exatamente o que cada módulo recebe e retorna permite que um subagente implemente a UI/CLI/integração ao mesmo tempo em que outro implementa o serviço ou camada de dados.
- **Validação no terminal ao final:** Exigir a execução real de build e testes no terminal obriga os subagentes a corrigirem erros de sintaxe, tipos e imports antes da entrega final.
- **Sem meta-instruções de orquestração:** O próprio seletor **Orchestrator (Argon)** no Antigravity gerencia o disparo dos subagentes Hydrogen; o prompt deve focar apenas no sistema, arquivos, contratos e regras.

---

## 2. Exemplo de Prompt Gerado Após Leitura de Workspace

Suponha que o agente leu um projeto TypeScript/Node com `package.json`, `src/db/userRepo.ts`, `src/routes/auth.ts`, `src/types/auth.ts` e `tests/auth.test.ts`:

```markdown
## Objetivo
Implementar o fluxo de refresh token com rotação automática e revogação de sessão no backend de autenticação. Isso resolve a expiração abrupta de sessões ativas e garante invalidação imediata caso um token já utilizado seja reapresentado.

## Contexto e Arquivos Base
Stack / Bibliotecas: TypeScript 5.4 / Node.js 20 / Fastify 4 / Prisma ORM / Vitest
Arquivos principais já existentes: `package.json`, `prisma/schema.prisma`, `src/types/auth.ts`, `src/db/userRepo.ts`, `src/routes/auth.ts`, `tests/auth.test.ts`
Padrões do projeto: Funções puras de domínio separadas dos handlers Fastify, validação de payloads com Zod, uso obrigatório de `async/await` e tipagem estrita sem alterar a assinatura atual de `loginHandler` em `src/routes/auth.ts`

## Escopo Modular (Entregáveis)
1. **Módulo 1 - Camada de Dados e Contratos:**
   Alterar `prisma/schema.prisma` e `src/types/auth.ts` para adicionar o modelo `RefreshToken` (`id`, `userId`, `tokenHash`, `expiresAt`, `revokedAt`) e os tipos `RefreshRequestDTO` e `TokenPairResult`.
   Entradas e saídas esperadas: Exporta `RefreshRequestDTO` (`{ refreshToken: string }`) e `TokenPairResult` (`{ accessToken: string; refreshToken: string; expiresIn: number }`).
2. **Módulo 2 - Serviço de Rotação e Revogação:**
   Criar `src/services/refreshTokenService.ts` para gerar tokens opacos, persistir hash SHA-256 via `src/db/userRepo.ts`, rotacionar o token válido em transação e revogar toda a família de tokens em caso de reuso.
   Entradas e saídas esperadas: Função `rotateRefreshToken(input: RefreshRequestDTO): Promise<TokenPairResult>` e `revokeUserTokens(userId: string): Promise<void>`.
3. **Módulo 3 - Rotas HTTP e Integração:**
   Alterar `src/routes/auth.ts` para conectar `rotateRefreshToken` no endpoint `POST /auth/refresh` e `revokeUserTokens` no `POST /auth/logout` com validação Zod.
4. **Módulo 4 - Testes e Validação:**
   Criar/estender testes automatizados em `tests/refreshToken.test.ts` cobrindo rotação com sucesso, token expirado, detecção de reuso (revogação em cascata) e payload inválido.

## Regras e Restrições
Não quebrar compatibilidade com o fluxo atual de `POST /auth/login` e com o formato de payload JWT usado pelos middlewares existentes.
Tratar erros explicitamente (sem blocos catch / except vazios), retornando status `401` para tokens inválidos/revogados e `400` para entrada malformada.
Antes de encerrar, execute `npm run build` e `npm test` no terminal para garantir que tudo compila e passa sem erros.
```
