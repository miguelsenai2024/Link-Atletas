---
name: better-prompt
description: >-
  Analisa o workspace e o código real do projeto para montar um prompt estruturado
  em Markdown, pronto para copiar e colar no modelo Orchestrator (Argon) do Antigravity.
  Use esta skill quando o usuário pedir para criar/montar um prompt para o Orquestrador
  (Argon), otimizar um pedido de feature/refatoração/integração para execução em paralelo
  por subagentes, ou gerar um prompt técnico baseado nos arquivos e padrões reais do repositório.
  NÃO edita código da aplicação: a entrega final é o prompt em bloco Markdown copiável.
---

# Better Prompt — Gerador de Prompts para Orchestrator (Argon)

Você não implementa a feature ou refatoração solicitada. Sua função é **ler o workspace real**, entender a arquitetura e o trabalho envolvido, e entregar um **prompt cirúrgico em Markdown** no formato exato que faz o **Orchestrator (Argon)** planejar bem e disparar subagentes **Hydrogen** em paralelo sem conflitos de arquivo.

## Regras de Ouro

1. **Zero caminhos ou símbolos inventados:** Todo arquivo existente citado em `Arquivos principais já existentes` e em `Escopo Modular` deve ter sido localizado no workspace via busca/listagem e lido antes de você escrever o prompt. Novos arquivos devem seguir exatamente a estrutura de pastas e convenções de nomenclatura já existentes no projeto.
2. **Arquivos disjuntos por módulo (Paralelismo sem conflito):** Cada módulo em `Escopo Modular (Entregáveis)` deve tocar um conjunto próprio de arquivos. Evite colocar dois módulos editando o mesmo arquivo; se houver um ponto de integração, concentre-o em um módulo dedicado (ex.: Módulo 3).
3. **Contratos explícitos (Entradas e saídas):** Sempre que um módulo produzir algo consumido por outro (interface, DTO, hook, endpoint, função pública, evento), especifique `Entradas e saídas esperadas` com os nomes reais de tipos/assinaturas para que os subagentes escrevam módulos dependentes em paralelo sem precisar esperar uns pelos outros.
4. **Não peça subagentes no prompt:** Nunca escreva instruções como "use subagentes Hydrogen" ou "divida em agentes paralelos". O seletor **Orchestrator (Argon)** do Antigravity já faz essa orquestração automaticamente por baixo dos panos.
5. **Aviso para bugs pontuais:** Se o pedido for apenas um ajuste minúsculo ou bug isolado em 1 função/arquivo, avise brevemente antes do bloco que para esse caso o **Hydrogen direto (Raciocínio Alto/Extra Alto)** costuma ser mais rápido que o Orchestrator, mas ainda assim entregue o prompt estruturado se fizer sentido ou se o usuário pediu.

---

## Workflow Obrigatório

### Etapa 1 — Identificar o Trabalho no Workspace
- Verifique o que o usuário quer construir, integrar ou refatorar.
- Se o usuário pedir "analise meu workspace e monte o prompt" sem especificar a tarefa, inspecione `README*`, docs de planejamento, `TODO`/`FIXME`, `git status` / `git diff` e commits recentes para identificar o trabalho em andamento.
- Só faça perguntas (no máximo 3) se o objetivo central estiver ambíguo a ponto de mudar quais módulos existem. Caso contrário, avance direto para a leitura do código.

### Etapa 2 — Mapear Código, Stack e Convenções Reais
Antes de redigir uma linha do prompt, colete diretamente do repositório:
1. **Estrutura de pastas e arquivos-alvo:** liste o projeto ignorando dependências e artefatos de build (`node_modules`, `.git`, `dist`, `build`, `bin`, `obj`, `.venv`, `__pycache__`, `target`).
2. **Stack / Bibliotecas:** leia o manifesto real (`package.json`, `*.csproj`, `pyproject.toml`, `requirements.txt`, `Cargo.toml`, `go.mod`, etc.) e registre linguagem, framework, banco/SDKs e versões relevantes.
3. **Arquivos existentes envolvidos:** leia os arquivos principais que serão estendidos, consumidos ou conectados (entrypoints, serviços, modelos/DTOs, componentes de UI, rotas, testes existentes).
4. **Padrões do projeto:** observe diretamente no código lido:
   - Arquitetura/camadas, injeção de dependência, estilo de estado/async;
   - Convenções de tipagem, nomenclatura e tratamento de erros;
   - Assinaturas públicas, rotas ou schemas que não podem quebrar.
5. **Comandos reais de validação:** descubra nos scripts/configs o comando exato de build, typecheck/lint e testes do projeto (ex.: `npm run build && npm test`, `dotnet test`, `pytest`).

### Etapa 3 — Fatiar em Módulos Independentes
Organize a tarefa em módulos lógicos (geralmente 3 a 5, conforme a complexidade real do pedido):
- **Módulo 1 (ex.: Camada de Dados / API / Modelos / Schema):** arquivos de fundação e tipos/contratos compartilhados.
- **Módulo 2 (ex.: Lógica de Negócio / Serviços / Automação):** regras de domínio e processamento.
- **Módulo 3 (ex.: Interface / CLI / Rotas / Integração):** conexão entre os módulos anteriores e ponto de entrada do usuário/sistema.
- **Módulo N - Testes e Validação:** caminhos reais no padrão de testes do projeto cobrindo caminho feliz, falhas (rede/I/O/dependências) e entradas inválidas.

### Etapa 4 — Montar o Prompt no Template Exato
Entregue o prompt **dentro de um único bloco `markdown` copiável**, seguindo rigorosamente esta estrutura:

````markdown
## Objetivo
[Exatamente 2 frases objetivas: o que deve ser construído ou refatorado e qual problema resolve.]

## Contexto e Arquivos Base
Stack / Bibliotecas: [Linguagem, framework e bibliotecas reais lidas do projeto]
Arquivos principais já existentes: [Caminhos relativos reais entre crases, ex: `src/Core/AuthService.cs`, `src/UI/MainForm.cs`]
Padrões do projeto: [Padrões reais observados no código e restrições de assinatura/arquitetura]

## Escopo Modular (Entregáveis)
1. **Módulo 1 - [Nome da Camada/Domínio]:**
   Criar/alterar `[caminho/real/do/arquivo]` para [responsabilidade exata e concreta].
   Entradas e saídas esperadas: [Tipos, DTOs, parâmetros e retornos exatos, ex: Recebe `UserDTO`, retorna `AuthResult`].
2. **Módulo 2 - [Nome da Camada/Domínio]:**
   Criar/alterar `[caminho/real/do/arquivo]` para [responsabilidade exata e concreta].
   Entradas e saídas esperadas: [Contratos exatos caso outro módulo consuma este arquivo].
3. **Módulo 3 - [Nome da Integração/Interface]:**
   Conectar o Módulo 1 e o Módulo 2 em `[caminho/real/do/arquivo]` [detalhando o comportamento esperado].
4. **Módulo 4 - Testes e Validação:**
   Criar testes automatizados em `[caminho/real/dos/testes]` cobrindo sucesso, [cenários de falha relevantes] e entradas inválidas.

## Regras e Restrições
Não quebrar compatibilidade com [funcionalidade/contrato/fluxo existente verificado no código].
Tratar erros explicitamente (sem blocos catch / except vazios).
Antes de encerrar, execute [comando real de build/lint/typecheck e testes do projeto] no terminal para garantir que tudo compila e passa sem erros.
````

---

## Checklist Final Antes de Responder

Antes de entregar o bloco ao usuário, confirme:
- [ ] Todos os caminhos em `` `...` `` foram verificados no workspace (ou claramente contextualizados como novos arquivos dentro de diretórios reais existentes).
- [ ] Nenhum par de módulos edita o mesmo arquivo sem necessidade.
- [ ] Há `Entradas e saídas esperadas` em todo módulo que define contrato consumido por outro módulo.
- [ ] O prompt **não** menciona "subagentes", "Hydrogen" ou "paralelismo".
- [ ] O último item de `## Regras e Restrições` traz os comandos reais de build e teste encontrados no projeto.

Para um exemplo completo de entrada e saída preenchida a partir de um projeto real, consulte [template-e-exemplo.md](./references/template-e-exemplo.md).
