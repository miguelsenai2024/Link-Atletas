# LinkAtletas — Movimento em comum

Landing page experimental independente, feita com HTML, CSS e JavaScript sem dependências. O código e todos os seus recursos estão nesta pasta. A implementação principal do site não foi alterada.

## Abrir

Abra `index.html` diretamente no navegador. Fotos e fonte são locais; o conteúdo e as interações funcionam sem internet.

Para testar junto da plataforma, execute o servidor Vite já existente na raiz e abra `/teste/index.html`. Os links de entrada e cadastro apontam para `../login`, a rota real do projeto. Ao abrir o HTML como arquivo ou em um servidor exclusivo desta pasta, esses links precisam de uma instância da plataforma para funcionar.

## Comportamento

- Menu compacto em telas pequenas, com fechamento ao navegar ou pressionar Escape.
- Mosaico e faixa de modalidades preenchem o seletor do formulário ao clicar.
- Formulário valida as três respostas e monta uma orientação inicial local. Não envia nem armazena dados e não simula profissionais ou compatibilidade real.
- Perguntas frequentes usam o elemento nativo `details`.
- Uma entrada escalonada no mosaico; feedback de clique em 140 ms; hover em 260 ms. Movimento reduzido e dispositivos sem hover são respeitados.

## Skills aplicadas

- `skills/skills-main/skills-main/skills/emil-design-eng/SKILL.md`
- `skills/skills-main/skills-main/skills/animate/SKILL.md`

A composição usa a referência fornecida: tipografia editorial, mosaico na abertura, duas áreas de público, blocos pastel, seção interativa, FAQ e uma assinatura grande no rodapé. A identidade e o símbolo são os da LinkAtletas.

O fundo principal usa `#181818` e os blocos usam `#232323`, conforme a amostra fornecida. A composição permanece a mesma, com textos claros e detalhes em cinza para manter a leitura.

## Imagens e fonte

- `treino-acompanhado.webp`: imagem já existente em `public/hero-training.webp`, copiada para manter o experimento independente.
- `corrida.jpg`: Colin Yarbrough, [Unsplash](https://unsplash.com/photos/topless-man-in-black-shorts-running-on-track-field-during-daytime-R1RTJ7m7eQY).
- `forca.jpg`: Sushil Ghimire, [Unsplash](https://unsplash.com/photos/woman-standing-and-carrying-barbell-eFx1KZhaSvo).
- `ciclismo.jpg`: fotografia de ciclismo disponibilizada pelo [Unsplash](https://unsplash.com/s/photos/bike-ride), arquivo original `photo-1534787238916-9ba6764efd4f`.
- Manrope: fonte distribuída pelo Google Fonts, licença SIL Open Font License. Usada também na identidade tipográfica do projeto principal.

As fotos são ilustrativas; não representam usuários, treinadores ou depoimentos da plataforma.

## Verificação

Layout e interações verificados em larguras de 320, 390, 768, 1024 e 1440 px. A checagem automática de acessibilidade foi executada em 390 e 1440 px. Resultados e capturas estão em `qa/`.

Para repetir, na raiz do repositório, sirva esta pasta com `python -m http.server 5190 --bind 127.0.0.1 --directory teste` e execute `node --max-old-space-size=256 --max-semi-space-size=1 teste/qa/verify.cjs`. O verificador usa as dependências de teste já instaladas no repositório e o Chrome do Windows; a página em si não precisa delas.
