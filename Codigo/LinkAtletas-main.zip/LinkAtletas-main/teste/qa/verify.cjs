// Run from the repository root while teste is served on port 5190.
const { chromium, expect } = require('@playwright/test')
const path = require('node:path')
const assert = require('node:assert/strict')
const fs = require('node:fs')

async function verify() {
  console.log('Starting browser verification')
  const browser = await chromium.launch({ executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe', headless: true })
  const results = []
  try {
    for (const width of [1440, 1024, 768, 390, 320]) {
      console.log(`Checking ${width}px`)
      const context = await browser.newContext({ viewport: { width, height: 1000 }, reducedMotion: 'reduce' })
      const page = await context.newPage()
      const errors = []
      page.on('pageerror', error => errors.push(error.message))
      await page.goto('http://127.0.0.1:5190/')
      await page.evaluate(async () => {
        document.querySelectorAll('img').forEach(image => { image.loading = 'eager' })
        await Promise.all([...document.images].map(image => image.decode().catch(() => {})))
        await document.fonts.ready
      })
      const layout = await page.evaluate(() => ({
        overflow: document.documentElement.scrollWidth > innerWidth,
        missingImages: [...document.images].filter(image => !image.complete || !image.naturalWidth).map(image => image.src),
        brokenAnchors: [...document.querySelectorAll('a[href^="#"]')].filter(a => !document.getElementById(a.hash.slice(1))).map(a => a.hash),
        fontLoaded: [...document.fonts].filter(font => font.family === 'Manrope').every(font => font.status === 'loaded'),
        h1Count: document.querySelectorAll('h1').length,
      }))
      assert.equal(layout.overflow, false, `Horizontal overflow at ${width}`)
      assert.deepEqual(layout.missingImages, [])
      assert.deepEqual(layout.brokenAnchors, [])
      assert.equal(layout.fontLoaded, true)
      assert.equal(layout.h1Count, 1)
      if (width === 1440 || width === 390) {
        await page.screenshot({ path: `teste/qa/hero-${width}.png` })
      }
      if (width < 761) {
        const button = page.locator('.menu-toggle')
        await button.click()
        await expect(button).toHaveAttribute('aria-expanded', 'true')
        await page.keyboard.press('Escape')
        await expect(button).toHaveAttribute('aria-expanded', 'false')
        await button.click()
        await page.locator('#navigation').getByRole('link', { name: 'Perguntas', exact: true }).click()
        await expect(button).toHaveAttribute('aria-expanded', 'false')
      }
      const form = page.locator('#match-form')
      await form.getByRole('button').click()
      await expect(page.locator('#match-result')).toBeHidden()
      await page.locator('[data-sport="Corrida"]').first().click()
      await expect(page.locator('#sport')).toHaveValue('Corrida')
      await page.locator('#goal').selectOption('constância')
      await page.locator('#format').selectOption('Online')
      await form.getByRole('button').click()
      await expect(page.locator('#match-result')).toContainText('Corrida · Acompanhamento online.')
      await expect(page.locator('#match-result')).toContainText('Construir uma rotina possível')
      await page.locator('#sport').selectOption('Ciclismo')
      await expect(page.locator('#match-result')).toBeHidden()
      const question = page.locator('.faq details').nth(1)
      await question.locator('summary').click()
      await expect(question).toHaveAttribute('open', '')
      assert.deepEqual(errors, [])
      let accessibility = { violations: [] }
      if (width === 1440 || width === 390) {
        const axePath = require.resolve('axe-core/axe.min.js', { paths: [path.dirname(require.resolve('@axe-core/playwright'))] })
        await page.addScriptTag({ path: axePath })
        accessibility = await page.evaluate(() => window.axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21aa'] } }))
      }
      const violations = accessibility.violations.map(({ id, impact, nodes }) => ({ id, impact, nodes: nodes.map(node => ({ target: node.target, summary: node.failureSummary })) }))
      results.push({ width, ...layout, errors, violations })
      console.log(JSON.stringify(results.at(-1)))
      await context.close()
    }
    fs.writeFileSync('teste/qa/results.json', JSON.stringify(results, null, 2))
    assert.ok(results.every(result => !result.violations.length), 'Accessibility issues found')
  } finally {
    await browser.close()
  }
}
verify().catch(error => { console.error(error); process.exit(1) })
