const menuButton = document.querySelector('.menu-toggle')
const navigation = document.querySelector('#navigation')

function closeMenu() {
  menuButton.setAttribute('aria-expanded', 'false')
  menuButton.setAttribute('aria-label', 'Abrir menu')
  navigation.classList.remove('is-open')
}

menuButton.addEventListener('click', () => {
  const open = menuButton.getAttribute('aria-expanded') !== 'true'
  menuButton.setAttribute('aria-expanded', String(open))
  menuButton.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu')
  navigation.classList.toggle('is-open', open)
})
navigation.addEventListener('click', (event) => {
  if (event.target.closest('a')) closeMenu()
})
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && menuButton.getAttribute('aria-expanded') === 'true') {
    closeMenu()
    menuButton.focus()
  }
})
matchMedia('(min-width: 761px)').addEventListener('change', closeMenu)

const sportSelect = document.querySelector('#sport')
const result = document.querySelector('#match-result')
document.querySelectorAll('[data-sport]').forEach((link) => {
  link.addEventListener('click', () => {
    sportSelect.value = link.dataset.sport
    result.hidden = true
  })
})

const goalCopy = {
  'começar': 'Começar com orientação e um plano que respeite seu ponto de partida.',
  'constância': 'Construir uma rotina possível, com acompanhamento ao longo do caminho.',
  'performance': 'Ajustar seus treinos aos seus objetivos e acompanhar a evolução com seu treinador.',
}
document.querySelector('#match-form').addEventListener('input', () => { result.hidden = true })
document.querySelector('#match-form').addEventListener('submit', (event) => {
  event.preventDefault()
  const data = new FormData(event.currentTarget)
  const sport = String(data.get('sport'))
  const goal = String(data.get('goal'))
  const format = String(data.get('format'))
  if (!sport || !goal || !format) return

  result.replaceChildren()
  const heading = document.createElement('h3')
  heading.textContent = 'Seu próximo passo já tem direção.'
  const description = document.createElement('p')
  description.textContent = `${sport} · Acompanhamento ${format.toLowerCase()}. ${goalCopy[goal]}`
  const link = document.createElement('a')
  link.className = 'text-link'
  link.href = '../login?perfil=atleta'
  link.textContent = 'Criar meu perfil na LinkAtletas ↗'
  const note = document.createElement('small')
  note.textContent = 'Prévia de jornada. A busca de profissionais acontece na plataforma, após o cadastro.'
  result.append(heading, description, link, note)
  result.hidden = false
  result.scrollIntoView({ block: 'nearest', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' })
})
