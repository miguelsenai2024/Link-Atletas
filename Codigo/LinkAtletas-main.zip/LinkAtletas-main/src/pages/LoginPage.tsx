import { useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { Eye, EyeOff } from 'lucide-react'
import { Logo } from '../components/Logo'
import { homeFor, useAuth } from '../context/AuthContext'

export function LoginPage() {
  const [params] = useSearchParams()
  const [registering, setRegistering] = useState(params.get('cadastro') === '1')
  const [role, setRole] = useState<'athlete' | 'coach'>(
    params.get('perfil') === 'treinador' ? 'coach' : 'athlete',
  )
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [show, setShow] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const auth = useAuth()
  const navigate = useNavigate()

  async function submit(event: React.FormEvent) {
    event.preventDefault()
    setLoading(true)
    setError('')
    try {
      const user = registering
        ? await auth.register(name, email, password, role)
        : await auth.login(email, password)
      navigate(homeFor(user.role))
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Não foi possível entrar.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="login-page">
      <div className="login-container">
        <div className="login-brand-panel">
          <Link to="/" aria-label="Voltar para o início" className="login-brand-logo">
            <Logo light />
          </Link>
          <h1>
            SUPERE
            <br />
            LIMITES
          </h1>
          <p className="login-brand-lead">
            Onde sua evolução esportiva se torna realidade.
          </p>
          <p className="login-brand-sub">
            Conecte-se a treinadores verificados e acompanhe cada etapa da sua
            jornada de alto rendimento.
          </p>
        </div>
        <main className="login-form-panel">
          <form onSubmit={submit} className="login-form">
            {registering && (
              <>
                <div className="role-switch">
                  <button
                    type="button"
                    className={role === 'athlete' ? 'active' : ''}
                    onClick={() => setRole('athlete')}
                  >
                    Sou atleta
                  </button>
                  <button
                    type="button"
                    className={role === 'coach' ? 'active' : ''}
                    onClick={() => setRole('coach')}
                  >
                    Sou treinador
                  </button>
                </div>
                <label>
                  Nome completo
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Digite seu nome completo"
                    minLength={2}
                    maxLength={100}
                    autoComplete="name"
                    required
                  />
                </label>
              </>
            )}
            <label>
              E-mail
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Digite seu e-mail"
                autoComplete="email"
                required
              />
            </label>
            <label>
              Senha
              <div className="password-field">
                <input
                  type={show ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  minLength={registering ? 8 : 1}
                  maxLength={128}
                  autoComplete={registering ? 'new-password' : 'current-password'}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShow(!show)}
                  aria-label={show ? 'Ocultar senha' : 'Mostrar senha'}
                >
                  {show ? <EyeOff /> : <Eye />}
                </button>
              </div>
              {!registering && (
                <Link className="live-link login-forgot-link" to="/recuperar-senha">
                  Esqueci minha senha
                </Link>
              )}
            </label>
            {registering && (
              <small className="login-register-hint">
                Use pelo menos 8 caracteres. Treinadores precisam enviar o CREF
                para análise após o cadastro.
              </small>
            )}
            {error && (
              <div role="alert" className="form-error">
                {error}
              </div>
            )}
            <button
              className="button button--large login-submit"
              disabled={loading}
            >
              {loading
                ? 'Aguarde…'
                : registering
                  ? 'Criar minha conta'
                  : 'Entrar na plataforma'}
            </button>
            <div className="login-divider">
              <span>ou</span>
            </div>
            <p className="signup-copy">
              {registering ? 'Já tem uma conta?' : 'Ainda não tem uma conta?'}{' '}
              <button
                type="button"
                onClick={() => {
                  setRegistering(!registering)
                  setError('')
                }}
              >
                {registering ? 'Entrar' : 'Criar cadastro'}
              </button>
            </p>
          </form>
        </main>
      </div>
    </div>
  )
}
